<?php 
class c_checkout {
    public function checkout() {


        $view = "views/cart/v_checkout.php";
        include "templates/front-end/layout.php";
    }
}