<?php 
define("DB_HOST","localhost");
define("DB_NAME","shopfashion");
define("DB_USER","root");
define("DB_PWD","");