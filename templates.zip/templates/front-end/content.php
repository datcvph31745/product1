<?php 
if(isset($view)) {
    include($view);
}